#ifndef _MCS_FWU_H
#define _MCS_FWU_H

#include <sys/types.h>

// MCS firmware upgrade protocol
#define FWU_MAX_DATA_LEN 960 // bytes
// FWU end packet and data header is 6 bytes
#define FWU_MIN_READ_LEN 6

#define SYNC_BYTE 0x42 // Sync Byte ('B')
#define PACK_CMD  0x43 // Command Packet ('C')
#define PACK_DATA 0x44 // Data Packet ('D')
#define PACK_IND  0x49 // Indication Packet ('I')

/* Upgrade Control Commands (Major Id: 0x1B) */
#define ID_UPGRADE_CTRL_CMD 0x1B

// Minor Id
#define CMD_UPGRADE_START             0x00
#define CMD_UPGRADE_DATA_TRANSFER_END 0x01
#define CMD_UPGRADE_RESERVED          0x02
#define CMD_HOST_READY_RESET          0x03

#define UPGRADE_TYPE_MAIN_FW          0x00
#define UPGRADE_TYPE_OPTION_DATA      0x01
#define UPGRADE_TYPE_VOICE_PROMPT     0x02
#define UPGRADE_TYPE_DEMO             0x03

/* Upgrade Indicator (Major Id: 0x1B) */
#define ID_UPGRADE_INDICATOR 0x1B

// Minor Id
#define IND_UPGRADE_STATE_CHANGE      0x00
#define IND_UPGRADE_DATA_TRANSFER_END 0x01
#define IND_UPGRADE_ACK               0x02

// Upgrade State Change Indicator
#define IND_UPGRADE_INIT_COMPLETE 0x0
#define IND_UPGRADIND             0x1
#define IND_UPGRADE_COMPLETE      0x2
#define IND_UPGRADE_FAIL          0x3

// Upgrade Data Transfer End Indicator
#define IND_OK                  0x0
#define IND_IMAGE_CHECKSUM_FAIL 0x1
#define IND_IMAGE_SIZE_FAIL     0x2
#define IND_IMAGE_VERIFY_FAIL   0x3

// Upgrade ACK Indicator

/* Data Packet */
// Data Source Type
#define DATA_SOURCE_SPP  0x70
#define DATA_SOURCE_OPP  0x71
#define DATA_SOURCE_UART 0x72
#define DATA_SOURCE_BLE  0x73

// ���ýṹ�����
#pragma pack(1)
struct fwu_header {
	uint8_t sync_byte;
	uint8_t pack_type;
	uint8_t major_id;
	uint8_t minor_id;
	uint8_t length;
};

struct fwu_data_header {
  uint8_t sync_byte;
  uint8_t pack_type;
  uint8_t major_id;
  uint8_t minor_id;
  uint8_t length[2];
};

struct fwu_init_packet {
  struct fwu_header header;
  uint8_t fw_size[3];
  uint8_t fw_checksum;
  uint8_t data_len[2];
  uint8_t upgrade_type;
  uint8_t checksum;
};

struct fwu_end_packet {
  struct fwu_header header;
  uint8_t checksum;
};

struct fwu_data_packet {
  struct fwu_data_header header;
  uint8_t reserved[2];
  uint8_t data[FWU_MAX_DATA_LEN];
  uint8_t checksum;
};

struct fwu_ack_packet {
  struct fwu_header header;
  uint8_t state;
  uint8_t checksum;
} ;

struct fwu_data_ack_packet {
  struct fwu_header header;
  uint8_t reserved[2];
  uint8_t checksum;
};

#pragma pack()

#endif /* _MCS_FWU_H */